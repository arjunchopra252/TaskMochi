package com.taskmochi.core.design.color

import androidx.compose.ui.graphics.Color

/**
 * Defines the colour palette for TaskMochi.  We provide separate values for
 * light and dark themes.  The values are chosen to be accessible (WCAG AA
 * compliant) while maintaining a soft pastel aesthetic.
 */

// Light theme colours
val md_theme_light_primary = Color(0xFFB39CD0)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_secondary = Color(0xFFA8D5BA)
val md_theme_light_onSecondary = Color(0xFF1F1F1F)
val md_theme_light_tertiary = Color(0xFFF7A9A8)
val md_theme_light_onTertiary = Color(0xFF1F1F1F)
val md_theme_light_background = Color(0xFFFFFFFF)
val md_theme_light_onBackground = Color(0xFF1F1F1F)
val md_theme_light_surface = Color(0xFFF7F5FA)
val md_theme_light_onSurface = Color(0xFF1F1F1F)

// Dark theme colours
val md_theme_dark_primary = Color(0xFF5F4B8B)
val md_theme_dark_onPrimary = Color(0xFFFFFFFF)
val md_theme_dark_secondary = Color(0xFF3E7357)
val md_theme_dark_onSecondary = Color(0xFFEAEAEA)
val md_theme_dark_tertiary = Color(0xFFA65856)
val md_theme_dark_onTertiary = Color(0xFFEAEAEA)
val md_theme_dark_background = Color(0xFF121212)
val md_theme_dark_onBackground = Color(0xFFEAEAEA)
val md_theme_dark_surface = Color(0xFF1E1B29)
val md_theme_dark_onSurface = Color(0xFFEAEAEA)