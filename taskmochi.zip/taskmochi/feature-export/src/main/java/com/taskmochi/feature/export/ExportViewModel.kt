package com.taskmochi.feature.export

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.taskmochi.core.data.TaskMochiDatabase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.taskmochi.feature.export.ExportRepository

/**
 * ViewModel for exporting and importing tasks.  All functions must be called
 * from the UI layer, which will handle file picking via the Storage Access
 * Framework.  This ViewModel does not itself interact with URIs; it simply
 * converts between JSON and entities.
 */
@HiltViewModel
class ExportViewModel @Inject constructor(
    private val db: TaskMochiDatabase
) : ViewModel() {
    private val repository by lazy { ExportRepository(db) }

    suspend fun exportToJson(): String = repository.exportToJson()

    fun importFromJson(json: String) {
        viewModelScope.launch {
            repository.importFromJson(json)
        }
    }
}