package com.taskmochi.feature.export

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.taskmochi.core.data.TaskMochiDatabase
import com.taskmochi.core.model.*
import kotlinx.coroutines.flow.first

/**
 * Handles exporting and importing TaskMochi data to and from JSON.  It relies
 * directly on the Room database instance to fetch all entities and insert
 * imported data.
 */
class ExportRepository(private val db: TaskMochiDatabase) {
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    /**
     * Serialises the entire database into a JSON string.  This can be saved
     * using the Storage Access Framework or any other mechanism.
     */
    suspend fun exportToJson(): String {
        val lists = db.listDao().getAll().first()
        val tasks = lists.flatMap { list -> db.taskDao().getTasksForList(list.id).first() }
        val subtasks = tasks.flatMap { task -> db.taskDao().getSubtasks(task.id).first() }
        val tags = db.tagDao().getAll().first()
        val crossRefs = db.taskDao().getAllTaskTagCrossRefs().first()
        val export = ExportData(lists, tasks, subtasks, tags, crossRefs)
        return gson.toJson(export)
    }

    /**
     * Imports the JSON string back into the database.  Existing tables are
     * cleared before insertion.  Use with caution.
     */
    suspend fun importFromJson(json: String) {
        val data = gson.fromJson(json, ExportData::class.java)
        db.clearAllTables()
        data.lists.forEach { db.listDao().insert(it) }
        data.tasks.forEach { db.taskDao().insert(it) }
        data.subtasks.forEach { db.taskDao().insertSubtask(it) }
        data.tags.forEach { db.tagDao().insert(it) }
        data.crossRefs.forEach { db.taskDao().insertTaskTagCrossRef(it) }
    }
}

/** Simple container for all persisted entities. */
data class ExportData(
    val lists: List<TaskListEntity> = emptyList(),
    val tasks: List<TaskEntity> = emptyList(),
    val subtasks: List<SubtaskEntity> = emptyList(),
    val tags: List<TagEntity> = emptyList(),
    val crossRefs: List<TaskTagCrossRef> = emptyList()
)