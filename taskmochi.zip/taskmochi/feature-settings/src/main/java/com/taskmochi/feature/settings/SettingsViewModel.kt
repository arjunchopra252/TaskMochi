package com.taskmochi.feature.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val SETTINGS_DATASTORE = "settings"

private val Context.dataStore by preferencesDataStore(name = SETTINGS_DATASTORE)

/** Enumerates the theme options available to the user. */
enum class ThemeOption { LIGHT, DARK, SYSTEM, ANIME }

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private object PreferencesKeys {
        val THEME = stringPreferencesKey("theme_option")
    }

    private val _theme: MutableStateFlow<ThemeOption> = MutableStateFlow(ThemeOption.ANIME)
    val theme: StateFlow<ThemeOption> = _theme

    init {
        viewModelScope.launch {
            context.dataStore.data.map { prefs ->
                prefs[PreferencesKeys.THEME]
            }.collect { value ->
                _theme.value = value?.let { runCatching { ThemeOption.valueOf(it) }.getOrElse { ThemeOption.ANIME } } ?: ThemeOption.ANIME
            }
        }
    }

    /** Persists the selected theme option. */
    fun setTheme(option: ThemeOption) {
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[PreferencesKeys.THEME] = option.name
            }
        }
    }
}