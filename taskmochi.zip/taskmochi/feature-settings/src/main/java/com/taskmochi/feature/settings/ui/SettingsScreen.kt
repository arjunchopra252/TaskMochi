package com.taskmochi.feature.settings.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.taskmochi.feature.settings.SettingsViewModel
import com.taskmochi.feature.settings.ThemeOption

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val themeOption by viewModel.theme.collectAsState()
    Scaffold(topBar = {
        TopAppBar(title = { Text("Settings") })
    }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Theme", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            ThemeOption.values().forEach { option ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(
                        selected = option == themeOption,
                        onClick = { viewModel.setTheme(option) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(option.name.lowercase().replaceFirstChar { it.uppercase() })
                }
            }
        }
    }
}