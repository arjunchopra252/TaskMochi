package com.taskmochi.core.data.dao

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.taskmochi.core.data.TaskMochiDatabase
import com.taskmochi.core.model.TaskEntity
import com.taskmochi.core.model.TaskListEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class TaskDaoTest {
    private lateinit var db: TaskMochiDatabase
    private lateinit var taskDao: TaskDao
    private lateinit var listDao: ListDao

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = Room.inMemoryDatabaseBuilder(context, TaskMochiDatabase::class.java).allowMainThreadQueries().build()
        taskDao = db.taskDao()
        listDao = db.listDao()
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun insertAndQueryTasks() = runBlocking {
        // create a list
        val listId = listDao.insert(TaskListEntity(name = "Personal", position = 0))
        // insert tasks
        val task1Id = taskDao.insert(TaskEntity(listId = listId, title = "Test", priority = 0))
        val task2Id = taskDao.insert(TaskEntity(listId = listId, title = "Another", priority = 1))
        // query tasks for list
        val tasks = taskDao.getTasksForList(listId).first()
        assertEquals(2, tasks.size)
        assertEquals("Another", tasks.first().title) // high priority appears first
    }
}