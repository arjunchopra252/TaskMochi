package com.taskmochi.core.data.repository

import com.taskmochi.core.data.dao.TaskDao
import com.taskmochi.core.model.SubtaskEntity
import com.taskmochi.core.model.TaskEntity
import com.taskmochi.core.model.TaskTagCrossRef
import kotlinx.coroutines.flow.Flow

/**
 * Repository that encapsulates operations on tasks and subtasks.  Business logic
 * such as setting reminder timestamps or marking tasks complete lives here.
 */
class TaskRepository(private val taskDao: TaskDao) {
    /** Returns a flow of tasks in the given list. */
    fun getTasksForList(listId: Long): Flow<List<TaskEntity>> = taskDao.getTasksForList(listId)

    suspend fun create(task: TaskEntity): Long = taskDao.insert(task)

    suspend fun update(task: TaskEntity) = taskDao.update(task)

    suspend fun delete(task: TaskEntity) = taskDao.delete(task)

    suspend fun setCompleted(taskId: Long, isCompleted: Boolean) {
        taskDao.setCompleted(taskId, isCompleted)
    }

    /** Subtask operations */
    fun getSubtasks(taskId: Long): Flow<List<SubtaskEntity>> = taskDao.getSubtasks(taskId)

    suspend fun addSubtask(subtask: SubtaskEntity): Long = taskDao.insertSubtask(subtask)

    suspend fun updateSubtask(subtask: SubtaskEntity) = taskDao.updateSubtask(subtask)

    suspend fun deleteSubtask(subtask: SubtaskEntity) = taskDao.deleteSubtask(subtask)

    /** Tag cross‑reference operations */
    suspend fun addTagToTask(taskId: Long, tagId: Long) =
        taskDao.insertTaskTagCrossRef(TaskTagCrossRef(taskId, tagId))

    suspend fun removeTagFromTask(taskId: Long, tagId: Long) =
        taskDao.deleteTaskTagCrossRef(TaskTagCrossRef(taskId, tagId))
}