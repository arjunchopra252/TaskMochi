package com.taskmochi.core.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.taskmochi.core.data.dao.ListDao
import com.taskmochi.core.data.dao.TaskDao
import com.taskmochi.core.data.dao.TagDao
import com.taskmochi.core.model.*

/**
 * Central Room database for TaskMochi.  Contains all entities and provides
 * DAO accessors.  Schema export is disabled because migrations are not
 * versioned in this demo; see `docs/` for upgrade guidance.
 */
@Database(
    entities = [
        TaskListEntity::class,
        TaskEntity::class,
        SubtaskEntity::class,
        TagEntity::class,
        TaskTagCrossRef::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TaskMochiDatabase : RoomDatabase() {
    abstract fun listDao(): ListDao
    abstract fun taskDao(): TaskDao
    abstract fun tagDao(): TagDao
}