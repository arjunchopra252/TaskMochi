package com.taskmochi.core.data.repository

import com.taskmochi.core.data.dao.ListDao
import com.taskmochi.core.model.TaskListEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

/**
 * Repository that exposes list operations to the rest of the application.  This
 * abstraction allows swapping the underlying storage (e.g. local vs. remote) without
 * changing the calling code.
 */
class ListRepository(private val listDao: ListDao) {
    fun getAll(): Flow<List<TaskListEntity>> = listDao.getAll()

    suspend fun create(name: String): Long {
        // Determine the next position based on the current number of lists.  If
        // there are no existing lists, start at position 0.
        val existing = listDao.getAll().firstOrNull() ?: emptyList()
        val position = existing.size
        return listDao.insert(TaskListEntity(name = name, position = position))
    }

    suspend fun rename(list: TaskListEntity, newName: String) {
        listDao.update(list.copy(name = newName))
    }

    suspend fun delete(list: TaskListEntity) {
        listDao.delete(list)
    }
}

private suspend fun <T> Flow<T>.firstOrNull(): T? {
    return try {
        kotlinx.coroutines.flow.firstOrNull(this)
    } catch (e: Exception) {
        null
    }
}