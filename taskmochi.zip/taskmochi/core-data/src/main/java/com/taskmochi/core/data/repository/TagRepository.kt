package com.taskmochi.core.data.repository

import com.taskmochi.core.data.dao.TagDao
import com.taskmochi.core.model.TagEntity
import kotlinx.coroutines.flow.Flow

/**
 * Repository for tags.  Tags can be created, edited or deleted and are
 * referenced by tasks via a cross‑reference table.
 */
class TagRepository(private val tagDao: TagDao) {
    fun getAll(): Flow<List<TagEntity>> = tagDao.getAll()

    suspend fun create(name: String): Long = tagDao.insert(TagEntity(name = name))

    suspend fun update(tag: TagEntity) = tagDao.update(tag)

    suspend fun delete(tag: TagEntity) = tagDao.delete(tag)
}