package com.taskmochi.core.data.dao

import androidx.room.*
import com.taskmochi.core.model.TaskListEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO for CRUD operations on task lists.
 */
@Dao
interface ListDao {
    @Query("SELECT * FROM task_lists ORDER BY position ASC")
    fun getAll(): Flow<List<TaskListEntity>>

    @Query("SELECT * FROM task_lists WHERE id = :id")
    suspend fun getById(id: Long): TaskListEntity?

    @Insert
    suspend fun insert(entity: TaskListEntity): Long

    @Update
    suspend fun update(entity: TaskListEntity)

    @Delete
    suspend fun delete(entity: TaskListEntity)
}