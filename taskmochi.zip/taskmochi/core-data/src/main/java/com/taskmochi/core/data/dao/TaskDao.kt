package com.taskmochi.core.data.dao

import androidx.room.*
import com.taskmochi.core.model.SubtaskEntity
import com.taskmochi.core.model.TagEntity
import com.taskmochi.core.model.TaskEntity
import com.taskmochi.core.model.TaskTagCrossRef
import kotlinx.coroutines.flow.Flow

/**
 * Data access object for tasks, subtasks and their relations.  This DAO
 * exposes flows that emit whenever the underlying tables change.
 */
@Dao
interface TaskDao {
    // region Task operations
    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: Long): TaskEntity?

    @Insert
    suspend fun insert(entity: TaskEntity): Long

    @Update
    suspend fun update(entity: TaskEntity)

    @Delete
    suspend fun delete(entity: TaskEntity)

    @Query("UPDATE tasks SET isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id")
    suspend fun setCompleted(id: Long, isCompleted: Boolean, updatedAt: Long = System.currentTimeMillis())

    /**
     * Returns a flow of all tasks in the given list, ordered by completion status,
     * priority (high to low) and due date ascending.
     */
    @Query("SELECT * FROM tasks WHERE listId = :listId ORDER BY isCompleted ASC, priority DESC, dueAt ASC")
    fun getTasksForList(listId: Long): Flow<List<TaskEntity>>

    // region Subtask operations
    @Query("SELECT * FROM subtasks WHERE taskId = :taskId ORDER BY position ASC")
    fun getSubtasks(taskId: Long): Flow<List<SubtaskEntity>>

    @Insert
    suspend fun insertSubtask(entity: SubtaskEntity): Long

    @Update
    suspend fun updateSubtask(entity: SubtaskEntity)

    @Delete
    suspend fun deleteSubtask(entity: SubtaskEntity)

    // region Tag relations
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTaskTagCrossRef(crossRef: TaskTagCrossRef)

    @Delete
    suspend fun deleteTaskTagCrossRef(crossRef: TaskTagCrossRef)

    /** Returns all task‑tag cross references. */
    @Query("SELECT * FROM task_tag_cross_ref")
    fun getAllTaskTagCrossRefs(): Flow<List<TaskTagCrossRef>>

    /**
     * Returns all tasks that have a reminder timestamp greater than the
     * specified [now] and that are not yet completed.  Used to reschedule
     * reminders after device reboot.
     */
    @Query("SELECT * FROM tasks WHERE remindAt > :now AND isCompleted = 0")
    suspend fun getAllWithReminders(now: Long = System.currentTimeMillis()): List<TaskEntity>
}