package com.taskmochi.core.data.dao

import androidx.room.*
import com.taskmochi.core.model.TagEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO for CRUD operations on tags.
 */
@Dao
interface TagDao {
    @Query("SELECT * FROM tags ORDER BY name ASC")
    fun getAll(): Flow<List<TagEntity>>

    @Query("SELECT * FROM tags WHERE id = :id")
    suspend fun getById(id: Long): TagEntity?

    @Insert
    suspend fun insert(entity: TagEntity): Long

    @Update
    suspend fun update(entity: TagEntity)

    @Delete
    suspend fun delete(entity: TagEntity)
}