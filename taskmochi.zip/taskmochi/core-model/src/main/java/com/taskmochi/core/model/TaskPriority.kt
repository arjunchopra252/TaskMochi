package com.taskmochi.core.model

/**
 * Priority levels for tasks.  These values are stored as ints in the database and
 * provide an ordering from lowest to highest urgency.
 */
enum class TaskPriority(val level: Int) {
    LOW(0),
    MEDIUM(1),
    HIGH(2);

    companion object {
        fun fromInt(level: Int): TaskPriority = when (level) {
            2 -> HIGH
            1 -> MEDIUM
            else -> LOW
        }
    }
}