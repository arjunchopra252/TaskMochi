package com.taskmochi.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

/**
 * Represents a list of tasks.  Users can create multiple lists and reorder them.
 */
@Entity(tableName = "task_lists")
data class TaskListEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val position: Int
)

/**
 * A single task entry.  Contains optional due date/time and reminder timestamp.
 */
@Entity(
    tableName = "tasks",
    indices = [
        Index("dueAt"),
        Index("remindAt"),
        Index("isCompleted")
    ]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val listId: Long,
    val title: String,
    val notes: String? = null,
    val dueAt: Long? = null,
    val remindAt: Long? = null,
    val priority: Int = TaskPriority.LOW.level,
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val recurrenceRule: String? = null
)

/**
 * Represents a step or child of a task.  Subtasks share the completion state of their parent.
 */
@Entity(tableName = "subtasks")
data class SubtaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val title: String,
    val isCompleted: Boolean = false,
    val position: Int
)

/**
 * Tags allow grouping tasks across lists.  Tags are user defined and stored in a separate table.
 */
@Entity(tableName = "tags")
data class TagEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

/**
 * Many‑to‑many cross‑reference between tasks and tags.
 */
@Entity(primaryKeys = ["taskId", "tagId"], tableName = "task_tag_cross_ref")
data class TaskTagCrossRef(
    val taskId: Long,
    val tagId: Long
)