rootProject.name = "TaskMochi"

// Include all feature and core modules.  The application module depends on these.
include(
    ":app",
    ":core-model",
    ":core-data",
    ":core-design",
    ":feature-tasks",
    ":feature-settings",
    ":feature-export"
)