package com.taskmochi.feature.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.taskmochi.core.data.repository.ListRepository
import com.taskmochi.core.data.repository.TaskRepository
import com.taskmochi.core.model.TaskEntity
import com.taskmochi.core.model.TaskListEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * The ViewModel exposes combined state for the list of lists and the tasks
 * within the currently selected list.  It also provides methods for adding
 * tasks, deleting tasks and toggling completion.
 */
@HiltViewModel
class TasksViewModel @Inject constructor(
    private val listRepository: ListRepository,
    private val taskRepository: TaskRepository
) : ViewModel() {

    /** The id of the currently selected list.  Null indicates no lists yet. */
    private val _selectedListId: MutableStateFlow<Long?> = MutableStateFlow(null)

    // Source flows for lists and the currently selected list id
    private val listsFlow: Flow<List<TaskListEntity>> = listRepository.getAll()

    private val tasksFlow: Flow<List<TaskEntity>> = _selectedListId.flatMapLatest { id ->
        id?.let { taskRepository.getTasksForList(it) } ?: flowOf(emptyList())
    }

    /**
     * Combined UI state flow that emits whenever the lists, selected list or tasks
     * change.  If there are no lists, tasks will be empty and currentListId null.
     */
    val uiState: StateFlow<TasksUiState> = combine(
        listsFlow,
        _selectedListId,
        tasksFlow
    ) { lists, selectedId, tasks ->
        val currentId = selectedId ?: lists.firstOrNull()?.id
        TasksUiState(lists = lists, tasks = tasks, currentListId = currentId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), TasksUiState())

    /** Selects the given list id, causing tasks to update. */
    fun selectList(listId: Long) {
        _selectedListId.value = listId
    }

    /** Adds a new task to the selected list. */
    fun addTask(title: String) {
        val listId = _selectedListId.value ?: return
        viewModelScope.launch {
            taskRepository.create(
                TaskEntity(
                    listId = listId,
                    title = title,
                    priority = com.taskmochi.core.model.TaskPriority.LOW.level,
                    isCompleted = false
                )
            )
        }
    }

    /** Toggles the completion state of a task. */
    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            taskRepository.setCompleted(task.id, !task.isCompleted)
        }
    }

    /** Deletes the specified task. */
    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            taskRepository.delete(task)
        }
    }
}

data class TasksUiState(
    val lists: List<TaskListEntity> = emptyList(),
    val tasks: List<TaskEntity> = emptyList(),
    val currentListId: Long? = null
)