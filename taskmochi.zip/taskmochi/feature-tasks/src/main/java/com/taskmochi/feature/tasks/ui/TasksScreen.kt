package com.taskmochi.feature.tasks.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.Add
import androidx.compose.material3.icons.filled.Delete
import androidx.compose.material3.icons.filled.MoreVert
import androidx.compose.material3.icons.filled.Task
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.taskmochi.core.model.TaskEntity
import com.taskmochi.core.model.TaskListEntity
import com.taskmochi.feature.tasks.TasksUiState
import com.taskmochi.feature.tasks.TasksViewModel

@Composable
fun TasksHomeScreen(
    viewModel: TasksViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("TaskMochi") })
        },
        floatingActionButton = {
            AddTaskFab { viewModel.addTask(it) }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            ListTabs(
                lists = uiState.lists,
                selectedId = uiState.currentListId,
                onSelect = { viewModel.selectList(it) }
            )
            if (uiState.lists.isEmpty()) {
                EmptyState()
            } else {
                TaskList(
                    tasks = uiState.tasks,
                    onToggle = { viewModel.toggleTask(it) },
                    onDelete = { viewModel.deleteTask(it) }
                )
            }
        }
    }
}

@Composable
private fun ListTabs(
    lists: List<TaskListEntity>,
    selectedId: Long?,
    onSelect: (Long) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = lists.indexOfFirst { it.id == selectedId }.coerceAtLeast(0),
        edgePadding = 0.dp
    ) {
        lists.forEachIndexed { index, list ->
            Tab(
                selected = list.id == selectedId || (selectedId == null && index == 0),
                onClick = { onSelect(list.id) },
                text = { Text(list.name) }
            )
        }
    }
}

@Composable
private fun TaskList(
    tasks: List<TaskEntity>,
    onToggle: (TaskEntity) -> Unit,
    onDelete: (TaskEntity) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(tasks, key = { it.id }) { task ->
            DismissibleTaskRow(task, onToggle, onDelete)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DismissibleTaskRow(
    task: TaskEntity,
    onToggle: (TaskEntity) -> Unit,
    onDelete: (TaskEntity) -> Unit
) {
    val dismissState = rememberDismissState(
        confirmValueChange = { value ->
            if (value == DismissValue.DismissedToStart) {
                onDelete(task)
            }
            false // Prevent automatic dismissal; we handle state manually
        }
    )
    SwipeToDismiss(
        state = dismissState,
        background = {
            val color = when (dismissState.dismissDirection) {
                DismissDirection.StartToEnd -> MaterialTheme.colorScheme.primary
                DismissDirection.EndToStart -> MaterialTheme.colorScheme.error
                null -> MaterialTheme.colorScheme.surface
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(color)
                    .padding(horizontal = 20.dp),
                contentAlignment = if (dismissState.dismissDirection == DismissDirection.StartToEnd) Alignment.CenterStart else Alignment.CenterEnd
            ) {
                val icon = if (dismissState.dismissDirection == DismissDirection.StartToEnd) Icons.Default.Task else Icons.Default.Delete
                Icon(icon, contentDescription = null)
            }
        },
        dismissContent = {
            TaskRow(task, onToggle)
        }
    )
}

@Composable
private fun TaskRow(task: TaskEntity, onToggle: (TaskEntity) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = task.isCompleted,
            onCheckedChange = { onToggle(task) }
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = task.title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
            )
            if (!task.notes.isNullOrEmpty()) {
                Text(
                    text = task.notes ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTaskFab(onAdd: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    FloatingActionButton(onClick = { open = true }) {
        Icon(Icons.Default.Add, contentDescription = "Add task")
    }
    if (open) {
        var textState by remember { mutableStateOf(TextFieldValue()) }
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text("New Task") },
            text = {
                OutlinedTextField(
                    value = textState,
                    onValueChange = { textState = it },
                    label = { Text("Task title") }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (textState.text.isNotBlank()) {
                            onAdd(textState.text.trim())
                        }
                        open = false
                    }
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { open = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Mascot illustration would go here; placeholder text used in this example.
            Text(
                text = "No tasks yet!",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Tap + to add your first task",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}