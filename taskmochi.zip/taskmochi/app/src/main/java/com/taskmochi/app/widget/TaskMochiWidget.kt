package com.taskmochi.app.widget

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.state.UpdateGlanceState
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.backgroundColor
import androidx.glance.appwidget.clickable
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Box
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.glance.unit.dp
import com.taskmochi.app.MainActivity
import com.taskmochi.core.design.color.md_theme_light_primary
import com.taskmochi.core.design.color.md_theme_light_onPrimary

/**
 * A simple Glance widget that displays a heading and opens the app when tapped.
 * In a future release this widget can display today's tasks and quick add.
 */
class TaskMochiWidget : GlanceAppWidget() {
    @Composable
    override fun Content() {
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .backgroundColor(ColorProvider(md_theme_light_primary))
                .clickable(actionStartActivity(MainActivity::class.java))
                .padding(16.dp)
        ) {
            Text(
                text = "TaskMochi",
                style = TextStyle(color = ColorProvider(md_theme_light_onPrimary))
            )
        }
    }
}

class TaskMochiWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = TaskMochiWidget()
}