package com.taskmochi.app.di

import android.app.AlarmManager
import android.content.Context
import androidx.room.Room
import com.taskmochi.core.data.TaskMochiDatabase
import com.taskmochi.core.data.dao.ListDao
import com.taskmochi.core.data.dao.TagDao
import com.taskmochi.core.data.dao.TaskDao
import com.taskmochi.core.data.repository.ListRepository
import com.taskmochi.core.data.repository.TagRepository
import com.taskmochi.core.data.repository.TaskRepository
import com.taskmochi.app.alarm.ReminderScheduler
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): TaskMochiDatabase =
        Room.databaseBuilder(
            context,
            TaskMochiDatabase::class.java,
            "taskmochi.db"
        ).build()

    @Provides
    fun provideListDao(db: TaskMochiDatabase): ListDao = db.listDao()

    @Provides
    fun provideTaskDao(db: TaskMochiDatabase): TaskDao = db.taskDao()

    @Provides
    fun provideTagDao(db: TaskMochiDatabase): TagDao = db.tagDao()

    @Provides
    @Singleton
    fun provideListRepository(listDao: ListDao): ListRepository = ListRepository(listDao)

    @Provides
    @Singleton
    fun provideTaskRepository(taskDao: TaskDao): TaskRepository = TaskRepository(taskDao)

    @Provides
    @Singleton
    fun provideTagRepository(tagDao: TagDao): TagRepository = TagRepository(tagDao)

    @Provides
    @Singleton
    fun provideAlarmManager(@ApplicationContext context: Context): AlarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    @Provides
    @Singleton
    fun provideReminderScheduler(
        @ApplicationContext context: Context,
        alarmManager: AlarmManager
    ): ReminderScheduler = ReminderScheduler(context, alarmManager)
}