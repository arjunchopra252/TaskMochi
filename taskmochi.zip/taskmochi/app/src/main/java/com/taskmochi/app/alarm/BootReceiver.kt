package com.taskmochi.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.taskmochi.core.data.dao.TaskDao

/**
 * Receives the BOOT_COMPLETED broadcast and reschedules any pending reminders.
 * Without this, alarms would be lost on reboot.
 */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject lateinit var taskDao: TaskDao
    @Inject lateinit var scheduler: ReminderScheduler

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_REBOOT) {
            CoroutineScope(Dispatchers.IO).launch {
                val tasks = taskDao.getAllWithReminders()
                tasks.forEach { scheduler.schedule(it) }
            }
        }
    }
}