package com.taskmochi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.taskmochi.core.design.theme.TaskMochiTheme
import com.taskmochi.feature.tasks.ui.TasksHomeScreen
import com.taskmochi.feature.settings.ui.SettingsScreen
import com.taskmochi.feature.settings.SettingsViewModel
import dagger.hilt.android.AndroidEntryPoint
import androidx.hilt.navigation.compose.hiltViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            val theme by settingsViewModel.theme.collectAsState()
            // Determine dark mode and anime mode.  When anime theme is chosen
            // we always use the custom pastel palette.  Otherwise follow system.
            val darkMode = when (theme) {
                com.taskmochi.feature.settings.ThemeOption.LIGHT -> false
                com.taskmochi.feature.settings.ThemeOption.DARK -> true
                com.taskmochi.feature.settings.ThemeOption.ANIME -> false
                com.taskmochi.feature.settings.ThemeOption.SYSTEM -> isSystemInDarkTheme()
            }
            val animeMode = theme == com.taskmochi.feature.settings.ThemeOption.ANIME
            TaskMochiTheme(animeMode = animeMode, useDarkTheme = darkMode) {
                TaskMochiApp()
            }
        }
    }
}

@Composable
fun TaskMochiApp() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = {
            BottomBar(navController)
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "tasks",
            modifier = Modifier.padding(padding)
        ) {
            composable("tasks") { TasksHomeScreen() }
            composable("settings") { SettingsScreen() }
            // Add export/import screen when implemented
        }
    }
}

@Composable
fun BottomBar(navController: NavController) {
    val items = listOf(
        NavItem("Tasks", "tasks"),
        NavItem("Settings", "settings")
    )
    NavigationBar {
        val currentDestination = navController.currentBackStackEntryAsState().value?.destination
        items.forEach { item ->
            NavigationBarItem(
                label = { Text(item.title) },
                selected = currentDestination?.route == item.route,
                onClick = { navController.navigate(item.route) },
                icon = { /* Could add icons here */ }
            )
        }
    }
}

data class NavItem(val title: String, val route: String)