# TaskMochi

TaskMochi is a simple, anime‑inspired task tracker built with **Kotlin** and **Jetpack Compose**.  It was designed to feel light and delightful while remaining fully offline and privacy‑friendly.  TaskMochi takes inspiration from Google Tasks but adds a pastel palette, a cute mascot, and a handful of productivity enhancements such as recurring tasks, subtasks and reminders.

## Features

* **Multiple Lists** – create, rename and reorder task lists to organise your projects or categories.
* **Tasks & Subtasks** – each task can have a title, description, due date & time, priority (Low/Med/High), optional tags and an arbitrary number of subtasks.
* **Quick Add & Gestures** – add a new task from a bottom sheet, swipe right to complete, swipe left to defer and undo with a snackbar.
* **Search & Filters** – search across titles, notes and tags; filter by Today, Upcoming and Completed.
* **Recurring Tasks** – set tasks to repeat daily, weekly or based on a custom rule.
* **Reminders** – local notifications scheduled via `AlarmManager#setExactAndAllowWhileIdle`, with graceful fallback when exact alarms are not permitted.
* **JSON Export/Import** – back up or migrate your data using the Storage Access Framework.  Tasks, lists, tags and subtasks are serialised into a single JSON file that can be restored at any time.
* **Home Screen Widget** – view your Today tasks and add a new task directly from your home screen using an Android Glance widget.
* **Offline First** – TaskMochi never sends data over the network.  All information lives locally using Room and is backed up via Android’s auto‑backup if enabled on your device.
* **Custom Themes** – choose Light, Dark, or *Anime+* pastel themes; toggle animations and adjust first day of the week in Settings.
* **Accessibility & RTL Support** – dynamic font sizes, TalkBack labels, large touch targets and right‑to‑left layout support.

## Installation

1. On your Android device (Android 8.0 Oreo or higher) open **Settings → Apps & notifications → Special app access → Install unknown apps**.  Grant your file manager or browser permission to install unknown apps.
2. Transfer the **APK** from the `app/build/outputs/apk/release/app-release.apk` (or `app-debug.apk`) onto your device.
3. Tap the APK file.  Confirm the install when prompted.
4. Launch **TaskMochi** from your app drawer.  On first launch you can choose your preferred theme and will be shown the empty state with our mascot.

## Building From Source

TaskMochi is an Android Studio project.  To build it yourself:

### Prerequisites

* **Android Studio Hedgehog** or newer.
* **JDK 17** installed and configured.  Gradle will also install a compatible JDK automatically if none is found.
* Android SDK platforms **API 24** through **API 35**.

### Steps

```bash
git clone https://example.com/taskmochi.git
cd taskmochi

# To build a debug APK:
./gradlew clean assembleDebug

# To build a release APK (signed with your own keystore):
./gradlew assembleRelease

# The resulting APKs will be under app/build/outputs/apk/<buildType>/
```

If you do not wish to provide your own release signing configuration, the `app-release-unsigned.apk` can still be installed on devices with a debug certificate using `adb install -r path/to/apk`.

## Permissions & Privacy

TaskMochi requests the minimum permissions needed for its feature set:

| Permission | Purpose |
|---|---|
| `POST_NOTIFICATIONS` (API 33+) | Show reminders and completion notifications. |
| `SCHEDULE_EXACT_ALARM` (API 31+) | Schedule exact reminders when allowed.  When not permitted, alarms fall back to inexact. |
| Storage Access Framework (no explicit permission) | Used when exporting or importing JSON via the file picker. |

The app contains **no networking code**, no advertising, analytics or trackers.  All data stays on your device and is only backed up if you enable Android Auto Backup under your Google account.  You can reset all data at any time from Settings → Data Reset.

## Screenshots

Below are example screenshots showing the home screen in light mode and the quick‑add bottom sheet.  These assets live in `docs/screenshots/` and are included for illustration.  When you run the app yourself, the content will reflect your own tasks and lists.

![Home screen – Light Mode](docs/screenshots/home_light.png)

![Quick Add sheet](docs/screenshots/quick_add.png)

## Testing

TaskMochi includes both **unit tests** and **instrumented tests**.  The core logic and database are unit tested using JUnit, and the Compose UI is tested via `androidx.compose.ui.test`.

To run all tests:

```bash
./gradlew testDebugUnitTest          # Run JVM unit tests
./gradlew connectedDebugAndroidTest  # Run instrumented tests on a connected device or emulator
```

The current test suite includes:

| Test Target | Purpose |
|---|---|
| **ViewModel tests** | Verify operations like adding/deleting tasks, toggling completion, and recurrence scheduling. |
| **DAO/Repository tests** | Ensure Room database reads and writes entities correctly and maintain referential integrity. |
| **Compose UI tests** | Check that lists display correctly, swipe gestures trigger the correct actions and state is preserved on rotation. |

All tests should pass; a summary of results is printed at the end of each task.

## Troubleshooting

* **Compilation fails with missing SDK** – Make sure you have installed API 24–35 via the Android SDK Manager.
* **`SCHEDULE_EXACT_ALARM` permission denied** – On Android 12+, users can deny exact alarms.  In that case, TaskMochi will schedule inexact alarms and you may receive reminders later than expected.
* **Export/Import fails** – Ensure you pick a valid location in your device’s file system and that the exported file remains unchanged.  Only JSON files generated by TaskMochi are accepted on import.
* **Gradle sync issues** – Delete the `.gradle` directory and rerun `./gradlew build`.  Ensure your internet connection is available for the first sync to download dependencies.

---

TaskMochi is licensed under the MIT License.  Contributions, bug reports and suggestions are welcome!