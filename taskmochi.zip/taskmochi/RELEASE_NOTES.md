# TaskMochi v1.0.0 – August 2025

This is the initial public release of **TaskMochi**, your anime‑inspired personal task tracker.

## Highlights

* **Task lists** with drag‑to‑reorder and rename support.
* **Tasks** with titles, notes, due date/time, reminder notifications, priority levels, optional tags and subtasks.
* **Recurring tasks** – daily, weekly or custom recurrence rules.
* **Quick add** bottom sheet and swipe gestures to complete or defer tasks with undo.
* **Search & simple filters** including Today, Upcoming and Completed.
* **Notifications & exact alarms** using `AlarmManager#setExactAndAllowWhileIdle` with graceful fallback when permission is denied.
* **Local storage** via Room; no internet permission is used.  Optional auto‑backup via Android.
* **Export/Import** tasks to a single JSON file through the Storage Access Framework.
* **Home screen widget** for Today tasks and quick add.
* **Anime‑themed design** with light, dark and pastel (Anime+) themes, a friendly mascot and gentle animations.
* **Accessibility** support including TalkBack labels, larger hit targets and dynamic type.

## Known Issues

* **Natural language quick add** is not yet implemented.  All fields must be entered manually.
* **Wear OS glance tile** is currently out of scope and may be added in a future release.
* **Cloud backup** is not available; only local JSON export/import and Android Auto Backup are supported.

Your feedback is welcome!  Please report bugs or request features via the project issue tracker.